const form = document.getElementById('artisanForm');
const message = document.getElementById('formMessage');

form.addEventListener('submit', function (event) {
  event.preventDefault();

  const name = document.getElementById('artisanName').value.trim();
  const language = document.getElementById('language').value;
  const description = document.getElementById('product').value.trim();
  const hasGiDocument = document.getElementById('gi').checked;

  if (!name || !language || !description) {
    message.textContent = 'Please complete the required fields.';
    return;
  }

  message.textContent =
    `Demo preview ready for ${name}. Language: ${language}. ` +
    `GI-related document indicated: ${hasGiDocument ? 'Yes' : 'No'}. ` +
    'This is only a local prototype; your details have not been saved or sent.';
});
