# Artisan Hub — Pure Silk Artisan Marketplace

Artisan Hub is a student project prototype concept for a digital marketplace that can help silk artisans present their craft stories to a wider audience.

## Prototype features
- Responsive landing page and sample marketplace cards
- Artisan registration form interface
- Local-language product description input
- UI concept for AI-assisted translation
- Proposed artisan/document verification workflow
- Optional GI-related document indicator

## Important limitations
This repository contains a front-end demonstration only. The form does not save or transmit data. AI translation, identity verification, silk-purity verification, GI verification, authentication, payments, product inventory, and backend services are not implemented. Sample product cards are illustrative and are not real or verified listings.

## Run locally
1. Download or clone this repository.
2. Open `index.html` in a web browser.

No build step is required for this static prototype. The Google Fonts import requires an internet connection; the page remains usable if the font service is unavailable.

## Publish with GitHub Pages
1. Open the repository on GitHub.
2. Go to **Settings** → **Pages**.
3. Under the build/deployment source, select **Deploy from a branch**.
4. Select the `main` branch and the `/ (root)` folder, then save.
5. Wait for the deployment to finish. GitHub will show the published site URL in the Pages section.

If your default branch is not named `main`, select the branch shown in your repository.

## Team: customize before submission
- Add your actual team members and project details.
- Replace the sample product cards with content your team is permitted to use.
- Add your actual implemented features to this README.
- Do not claim backend, AI, or verification features work unless your team has implemented and tested them.
